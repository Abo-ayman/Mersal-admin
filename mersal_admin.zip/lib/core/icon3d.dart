import 'package:flutter/material.dart';

/// Master switch. false = the normal Material icons (previous identity). true = the 3D icon pack.
const bool kUse3DIcons = false;

/// Icon wrapper. With [kUse3DIcons] on, icons that have a 3D equivalent are drawn from assets/icons;
/// everything else (and everything while the switch is off) is a normal Material icon.
class I3 extends StatelessWidget {
  final IconData icon;
  final double? size;
  final Color? color;
  const I3(this.icon, {super.key, this.size, this.color});

  @override
  Widget build(BuildContext context) {
    final m = kUse3DIcons ? _icon3dMap[icon] : null;
    final s = size ?? IconTheme.of(context).size ?? 24;
    if (m == null) return Icon(icon, size: s, color: color);
    final img = Image.asset('assets/icons/${m.$1}.png', width: s, height: s, fit: BoxFit.contain);
    return m.$2 >= 1 ? img : Opacity(opacity: m.$2, child: img);
  }
}

/// Material icon -> (asset name, opacity). Icons not listed here keep their Material look.
final Map<IconData, (String, double)> _icon3dMap = {
  Icons.home: ('home', 1), Icons.home_rounded: ('home', 1), Icons.home_outlined: ('home', 1),
  Icons.door_front_door_outlined: ('home', 1),
  Icons.receipt_long: ('orders', 1), Icons.receipt_long_rounded: ('orders', 1), Icons.receipt_long_outlined: ('orders', 1),
  Icons.inventory_2_outlined: ('orders', 1),
  Icons.shopping_bag: ('cart', 1), Icons.shopping_bag_rounded: ('cart', 1), Icons.shopping_bag_outlined: ('cart', 1),
  Icons.shopping_cart: ('cart', 1),
  Icons.notifications: ('notifications', 1), Icons.notifications_none_rounded: ('notifications', 1),
  Icons.campaign: ('notifications', 1), Icons.campaign_outlined: ('notifications', 1),
  Icons.person: ('profile', 1), Icons.person_outline: ('profile', 1), Icons.person_outline_rounded: ('profile', 1),
  Icons.people_outline: ('profile', 1), Icons.person_add_alt_1_outlined: ('profile', 1),
  Icons.location_on: ('location', 1), Icons.location_on_outlined: ('location', 1), Icons.location_pin: ('location', 1),
  Icons.place: ('location', 1), Icons.place_outlined: ('location', 1), Icons.my_location: ('location', 1),
  Icons.location_searching: ('location', 1), Icons.near_me_rounded: ('location', 1), Icons.location_city: ('location', 1),
  Icons.map_outlined: ('map', 1), Icons.map: ('map', 1), Icons.route: ('map', 1),
  Icons.flag: ('new_location', 1), Icons.flag_outlined: ('new_location', 1),
  Icons.search: ('search', 1),
  Icons.call: ('call', 1), Icons.phone_outlined: ('call', 1),
  Icons.chat_bubble_outline: ('chat', 1), Icons.mark_chat_unread: ('chat', 1), Icons.chat: ('chat', 1),
  Icons.send: ('message', 1), Icons.send_rounded: ('message', 1), Icons.message: ('message', 1),
  Icons.add: ('add', 1), Icons.add_rounded: ('add', 1), Icons.add_circle_outline: ('add', 1),
  Icons.remove: ('remove', 1), Icons.remove_circle_outline: ('remove', 1),
  Icons.delete: ('delete', 1), Icons.delete_outline: ('delete', 1),
  Icons.edit: ('edit', 1), Icons.notes_outlined: ('edit', 1),
  Icons.refresh: ('refresh', 1),
  Icons.check: ('success', 1), Icons.check_circle: ('success', 1),
  Icons.report_gmailerrorred_outlined: ('warning', 1), Icons.warning_amber_rounded: ('warning', 1),
  Icons.error_outline: ('error', 1),
  Icons.star_rounded: ('rate', 1), Icons.star_outline_rounded: ('rate', 0.3),
  Icons.local_offer: ('offers', 1), Icons.local_offer_outlined: ('offers', 1), Icons.card_giftcard: ('offers', 1),
  Icons.account_balance_wallet_outlined: ('wallet', 1),
  Icons.payments_outlined: ('payment', 1),
  Icons.delivery_dining: ('delivery', 1), Icons.delivery_dining_rounded: ('delivery', 1),
  Icons.local_shipping_outlined: ('delivery', 1),
  Icons.local_taxi_rounded: ('scooter_3d', 1),
  Icons.restaurant: ('restaurants', 1), Icons.restaurant_rounded: ('restaurants', 1),
  Icons.soup_kitchen: ('food_3d', 1), Icons.outdoor_grill: ('food_3d', 1), Icons.lunch_dining: ('food_3d', 1),
  Icons.fastfood: ('food_3d', 1), Icons.local_drink: ('food_3d', 1),
  Icons.storefront: ('store_3d', 1), Icons.storefront_outlined: ('store_3d', 1),
  Icons.shopping_basket: ('stores', 1), Icons.shopping_basket_rounded: ('stores', 1), Icons.shopping_basket_outlined: ('stores', 1),
  Icons.local_pharmacy: ('pharmacy', 1), Icons.medical_services_rounded: ('pharmacy', 1),
  Icons.event: ('calendar', 1),
  Icons.help_outline: ('help', 1), Icons.info_outline: ('info', 1),
  Icons.image_outlined: ('camera', 1),
  Icons.schedule: ('time', 1),
  Icons.close: ('close', 1), Icons.settings: ('settings', 1), Icons.share: ('share', 1),
};

import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// All server calls of the admin app. Every call is re-checked on the server (admin role).
class AdminRepository {
  SupabaseClient get _db => Supabase.instance.client;

  bool get signedIn => _db.auth.currentSession != null;

  Future<void> signIn(String email, String password) =>
      _db.auth.signInWithPassword(email: email.trim(), password: password);

  Future<void> signOut() => _db.auth.signOut();

  Future<bool> isAdmin() async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return false;
    final r = await _db.rpc('is_admin', params: {'p_uid': uid});
    return r == true;
  }

  Future<List<Map<String, dynamic>>> _list(String fn, {Map<String, dynamic>? params}) async {
    final r = await _db.rpc(fn, params: params);
    return List<Map<String, dynamic>>.from(r as List);
  }

  Future<List<Map<String, dynamic>>> accounts() => _list('admin_accounts');
  Future<List<Map<String, dynamic>>> accountOrders(String userId) async =>
      _withCurrency(await _list('admin_account_orders', params: {'p_user': userId}), 'id');
  Future<List<Map<String, dynamic>>> orderMessages(String orderId) =>
      _list('admin_order_messages', params: {'p_order': orderId});
  Future<List<Map<String, dynamic>>> feeDrivers() => _list('admin_fee_drivers');
  Future<List<Map<String, dynamic>>> activeOrders() async =>
      _withCurrency(await _list('admin_active_orders'), 'id');
  Future<List<Map<String, dynamic>>> complaints() async =>
      _withCurrency(await _list('admin_complaints'), 'order_id');

  /// Adds 'currency_symbol' to each row (the order's own currency: ل.ت for Jarabulus, ل.س for Maskanah).
  Future<List<Map<String, dynamic>>> _withCurrency(
      List<Map<String, dynamic>> rows, String idKey) async {
    final ids = rows.map((r) => r[idKey]).whereType<String>().toSet().toList();
    if (ids.isEmpty) return rows;
    try {
      final cur = await _list('admin_order_currencies', params: {'p_ids': ids});
      final m = {for (final c in cur) c['order_id'] as String: c['currency_symbol'] as String};
      for (final r in rows) {
        final s = m[r[idKey]];
        if (s != null) r['currency_symbol'] = s;
      }
    } catch (_) {}
    return rows;
  }

  /// Unpaid company fees per driver as text, one amount per currency: "125 ل.س + 40 ل.ت".
  Future<Map<String, String>> feeTotalsText() async {
    final rows = await _list('admin_fee_totals');
    final by = <String, List<String>>{};
    for (final r in rows) {
      by.putIfAbsent(r['driver_id'] as String, () => []).add(
          '${fmtNum(r['total'] as num)} ${r['currency_symbol']}');
    }
    return {for (final e in by.entries) e.key: e.value.join(' + ')};
  }

  // ---------------------------------------------------------------- offers
  Future<List<Map<String, dynamic>>> cities() async {
    final rows = await _db.from('cities').select('id, name').eq('is_active', true).order('sort_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> offers() => _list('admin_list_offers');

  Future<void> createOffer({
    required String title,
    required String body,
    required DateTime expiresAt,
    DateTime? startsAt,
    String? cityId,
  }) =>
      _db.rpc('admin_create_offer', params: {
        'p_title': title,
        'p_body': body,
        'p_expires_at': expiresAt.toUtc().toIso8601String(),
        'p_city_id': cityId,
        'p_starts_at': startsAt?.toUtc().toIso8601String(),
      });

  Future<void> setOfferActive(String id, bool active) =>
      _db.rpc('admin_set_offer_active', params: {'p_id': id, 'p_active': active});

  Future<void> deleteOffer(String id) => _db.rpc('admin_delete_offer', params: {'p_id': id});

  // ------------------------------------------------------------ broadcasts
  /// audience: 'customers' | 'drivers' | 'all'. Returns how many users will get the notification.
  Future<int> sendBroadcast(String title, String body, String audience) async {
    final r = await _db.rpc('admin_send_broadcast',
        params: {'p_title': title, 'p_body': body, 'p_audience': audience});
    return (r as num).toInt();
  }

  Future<List<Map<String, dynamic>>> broadcasts() => _list('admin_list_broadcasts');
  Future<List<Map<String, dynamic>>> userRatings(String userId) =>
      _list('admin_user_ratings', params: {'p_user': userId});

  Future<void> resolveComplaint(String id, {String? note}) =>
      _db.rpc('admin_resolve_complaint', params: {'p_id': id, 'p_note': note});

  /// Average stars and count received by an account, or null if never rated.
  Future<({double avg, int count})?> userRating(String userId) async {
    final rows = await _list('user_rating', params: {'p_user': userId});
    if (rows.isEmpty) return null;
    final c = (rows.first['rating_count'] as num?)?.toInt() ?? 0;
    final a = rows.first['avg_stars'];
    if (c == 0 || a == null) return null;
    return (avg: (a as num).toDouble(), count: c);
  }

  /// Marks all unpaid fees of the driver as paid; returns how many were settled.
  Future<Map<String, dynamic>> accountSuspension(String userId) async {
    final rows = await _db.rpc('admin_account_suspension', params: {'p_user': userId}) as List;
    return rows.isEmpty ? {} : Map<String, dynamic>.from(rows.first as Map);
  }

  Future<void> setSuspension(String userId, bool suspend, {String? reason}) async {
    await _db.rpc('admin_set_suspension',
        params: {'p_user': userId, 'p_suspend': suspend, 'p_reason': reason});
  }

  Future<int> settleFees(String driverId, {String? note}) async {
    final r = await _db.rpc('settle_company_fees', params: {'p_driver': driverId, 'p_note': note});
    return (r as num).toInt();
  }

  Future<List<Map<String, dynamic>>> stores() async {
    final rows = await _db
        .from('stores')
        .select('*, store_categories(name)')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> storeCategories() async {
    final rows = await _db.from('store_categories').select().order('sort_order').order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> setStoreActive(String storeId, bool active) =>
      _db.rpc('admin_set_store_active', params: {'p_store': storeId, 'p_active': active});

  Future<String> createStoreCategory(String name) async {
    final r = await _db.rpc('admin_create_store_category', params: {'p_name': name});
    return r as String;
  }

  Future<String> createStore({
    required String name,
    String? description,
    String? phone,
    String? address,
    String? categoryId,
    double? lat,
    double? lon,
  }) async {
    final r = await _db.rpc('admin_create_store', params: {
      'p_name': name,
      'p_description': description,
      'p_phone': phone,
      'p_address': address,
      'p_lat': lat,
      'p_lon': lon,
      'p_category_id': categoryId,
      'p_image_url': null,
    });
    return r as String;
  }

  /// The store position is used to compute delivery fees for its products.
  Future<void> setStoreLocation(String storeId, double lat, double lon) =>
      _db.rpc('admin_set_store_location', params: {'p_store': storeId, 'p_lat': lat, 'p_lon': lon});

  /// Creates a driver or seller account (server-side, admin only).
  Future<void> createUser({
    required String email,
    required String password,
    required String fullName,
    String? phone,
    required String role, // 'driver' | 'seller'
    String? storeId,
  }) async {
    try {
      final res = await _db.functions.invoke('admin-create-user', body: {
        'email': email,
        'password': password,
        'full_name': fullName,
        'phone': phone,
        'role': role,
        'store_id': storeId,
      });
      final data = res.data;
      if (data is Map && data['error'] != null) throw Exception('${data['error']}');
    } on FunctionException catch (e) {
      final d = e.details;
      throw Exception(d is Map ? '${d['error']}' : '$d');
    }
  }
}

const statusAr = {
  'awaiting_review': 'بانتظار المراجعة',
  'awaiting_customer_approval': 'بانتظار موافقة الزبون',
  'pending_driver': 'بانتظار قبول السائق',
  'processing': 'جارٍ التجهيز',
  'ready': 'جاهز للتوصيل',
  'on_the_way': 'في الطريق',
  'arrived': 'وصل عند الباب',
  'delivered': 'تم التسليم',
  'rejected': 'مرفوض',
  'cancelled': 'ملغى',
};

const roleAr = {
  'customer': 'زبون',
  'driver': 'سائق',
  'taxi_driver': 'سائق تاكسي',
  'admin': 'مسؤول',
  'seller': 'متجر',
};

String friendlyError(Object e) {
  final m = e.toString();
  if (m.contains('email_exists')) return 'هذا البريد مسجّل مسبقاً';
  if (m.contains('weak_password')) return 'كلمة المرور يجب ألا تقل عن 8 أحرف';
  if (m.contains('invalid_email')) return 'البريد الإلكتروني غير صحيح';
  if (m.contains('name_required')) return 'الاسم مطلوب';
  if (m.contains('store_required')) return 'اختر المتجر لحساب المتجر';
  if (m.contains('invalid_location')) return 'الموقع غير صحيح';
  if (m.contains('not_allowed')) return 'ليست لديك صلاحية لهذا الإجراء';
  if (m.contains('title_required') || m.contains('invalid_title')) return 'العنوان مطلوب (80 حرفاً كحد أقصى)';
  if (m.contains('body_required') || m.contains('invalid_body')) return 'النص مطلوب (300 حرف للإشعار، و500 للعرض)';
  if (m.contains('invalid_expiry')) return 'تاريخ انتهاء العرض يجب أن يكون بعد تاريخ بدايته';
  if (m.contains('Invalid login')) return 'البريد أو كلمة المرور غير صحيحة';
  return 'حدث خطأ، حاول مرة أخرى';
}

String fmtNum(num n) => n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(2);

String fmtDate(dynamic iso) {
  final d = DateTime.tryParse('$iso')?.toLocal();
  return d == null ? '-' : DateFormat('yyyy/MM/dd  HH:mm').format(d);
}

String accountName(Map<String, dynamic> a) {
  for (final k in ['display_name', 'full_name', 'email']) {
    final v = a[k];
    if (v is String && v.trim().isNotEmpty) return v;
  }
  return 'بدون اسم';
}

import 'package:flutter/material.dart';

import '../data/admin_repository.dart';
import 'create_offer_screen.dart';

const _statusLabel = {
  'active': ('ساري', Colors.green),
  'scheduled': ('مجدول', Colors.blue),
  'expired': ('منتهٍ', Colors.grey),
  'paused': ('موقوف', Colors.orange),
};

class OffersScreen extends StatefulWidget {
  const OffersScreen({super.key});

  @override
  State<OffersScreen> createState() => _OffersScreenState();
}

class _OffersScreenState extends State<OffersScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.offers();

  void _reload() => setState(() => _future = _repo.offers());

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _toggle(Map<String, dynamic> o, bool v) async {
    try {
      await _repo.setOfferActive(o['id'], v);
    } catch (e) {
      _msg(friendlyError(e));
    }
    _reload();
  }

  Future<void> _delete(Map<String, dynamic> o) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف العرض'),
        content: Text('حذف «${o['title']}» نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _repo.deleteOffer(o['id']);
    } catch (e) {
      _msg(friendlyError(e));
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context)
              .push<bool>(MaterialPageRoute(builder: (_) => const CreateOfferScreen()));
          if (created == true) _reload();
        },
        icon: const Icon(Icons.add),
        label: const Text('عرض جديد'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                const SizedBox(height: 100),
                const Center(child: Text('تعذر تحميل العروض')),
                Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
              ]);
            }
            final list = snap.data!;
            if (list.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 100),
                Center(child: Text('لا توجد عروض. أضف أول عرض بالزر أدناه')),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final o = list[i];
                final st = _statusLabel[o['status']] ?? ('${o['status']}', Colors.grey);
                final status = '${o['status']}';
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(
                          child: Text('${o['title']}',
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        ),
                        Chip(
                          label: Text(st.$1, style: TextStyle(color: st.$2)),
                          side: BorderSide.none,
                          backgroundColor: st.$2.withValues(alpha: 0.12),
                        ),
                      ]),
                      Text('${o['body']}'),
                      const SizedBox(height: 6),
                      Text('المدينة: ${o['city_name'] ?? 'كل المدن'}',
                          style: const TextStyle(color: Colors.black54)),
                      Text('من ${fmtDate(o['starts_at'])}', style: const TextStyle(color: Colors.black54)),
                      Text('إلى ${fmtDate(o['expires_at'])}', style: const TextStyle(color: Colors.black54)),
                      Row(children: [
                        if (status != 'expired') ...[
                          const Text('مفعّل'),
                          Switch(value: o['is_active'] == true, onChanged: (v) => _toggle(o, v)),
                        ],
                        const Spacer(),
                        IconButton(
                            onPressed: () => _delete(o),
                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                            tooltip: 'حذف'),
                      ]),
                    ]),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

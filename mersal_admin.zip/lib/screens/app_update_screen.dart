import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Requires the customer or driver app to update. Builds older than the minimum build are blocked
/// with a screen that links to the update; builds at or above it keep working.
class AppUpdateScreen extends StatefulWidget {
  const AppUpdateScreen({super.key});

  @override
  State<AppUpdateScreen> createState() => _AppUpdateScreenState();
}

class _AppUpdateScreenState extends State<AppUpdateScreen> {
  static const _apps = {'customer': 'تطبيق الزبون', 'driver': 'تطبيق السائق'};
  final Map<String, bool> _enabled = {};
  final Map<String, TextEditingController> _urls = {
    for (final app in _apps.keys) app: TextEditingController(),
  };
  final Map<String, TextEditingController> _builds = {
    for (final app in _apps.keys) app: TextEditingController(),
  };
  final Map<String, bool> _saving = {};
  bool _loaded = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [..._urls.values, ..._builds.values]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await Supabase.instance.client.rpc('admin_app_updates') as List;
      for (final r in rows) {
        final m = r as Map<String, dynamic>;
        final app = m['app'] as String;
        _enabled[app] = m['enabled'] == true;
        _urls[app]?.text = (m['url'] ?? '') as String;
        _builds[app]?.text = '${m['min_build'] ?? 0}';
      }
      if (mounted) setState(() => _loaded = true);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  void _msg(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _save(String app) async {
    final enabled = _enabled[app] ?? false;
    final url = _urls[app]!.text.trim();
    final build = int.tryParse(_builds[app]!.text.trim());
    if (build == null || build < 0) {
      _msg('أدخل رقم نسخة صحيحاً (0 أو أكبر)');
      return;
    }
    if (enabled && !RegExp(r'^https?://', caseSensitive: false).hasMatch(url)) {
      _msg('أدخل رابطاً يبدأ بـ https://');
      return;
    }
    if (enabled) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text('إطلاق تحديث لـ${_apps[app]}؟'),
          content: Text(
            'كل نسخ ${_apps[app]} برقم أقل من $build ستُحجب فوراً ولن تعمل حتى تُحدَّث.\n\n'
            'الرابط: $url\n\n'
            'تأكد أن النسخة الجديدة منشورة وأن الرابط يعمل قبل الإطلاق.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('إطلاق التحديث')),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => _saving[app] = true);
    try {
      await Supabase.instance.client.rpc('admin_set_app_update_v2', params: {
        'p_app': app,
        'p_enabled': enabled,
        'p_url': url,
        'p_min_build': build,
      });
      _msg(enabled
          ? 'تم إطلاق التحديث لـ${_apps[app]}: النسخ الأقدم من $build محجوبة'
          : 'تم إيقاف التحديث لـ${_apps[app]}');
    } catch (e) {
      _msg('تعذر الحفظ: $e');
    } finally {
      if (mounted) setState(() => _saving[app] = false);
    }
  }

  Widget _card(String app) {
    final enabled = _enabled[app] ?? false;
    final saving = _saving[app] == true;
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(_apps[app]!, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('إطلاق تحديث'),
            subtitle: Text(enabled ? 'النسخ الأقدم من الرقم أدناه محجوبة' : 'التطبيق يعمل بشكل طبيعي'),
            value: enabled,
            onChanged: saving ? null : (v) => setState(() => _enabled[app] = v),
          ),
          TextField(
            controller: _builds[app],
            keyboardType: TextInputType.number,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              labelText: 'أقل رقم نسخة مسموح (رقم البناء)',
              helperText: 'مثال: 2 تعني أن النسخ برقم 1 وما دونه تُحجب',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _urls[app],
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(labelText: 'رابط التحديث (https://...)'),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: saving ? null : () => _save(app),
            child: Text(saving ? 'جارٍ الحفظ…' : 'حفظ'),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Center(
          child: _error == null
              ? const CircularProgressIndicator()
              : Text('تعذر التحميل: $_error', textAlign: TextAlign.center));
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [for (final app in _apps.keys) _card(app)],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Forces the customer or driver app to update: the app shows a blocking screen with this link.
class AppUpdateScreen extends StatefulWidget {
  const AppUpdateScreen({super.key});

  @override
  State<AppUpdateScreen> createState() => _AppUpdateScreenState();
}

class _AppUpdateScreenState extends State<AppUpdateScreen> {
  static const _apps = {'customer': 'تطبيق الزبون', 'driver': 'تطبيق السائق'};
  final Map<String, bool> _enabled = {};
  final Map<String, TextEditingController> _urls = {
    for (final app in _apps.keys) app: TextEditingController(),
  };
  final Map<String, bool> _saving = {};
  bool _loaded = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _urls.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await Supabase.instance.client.rpc('admin_app_updates') as List;
      for (final r in rows) {
        final m = r as Map<String, dynamic>;
        final app = m['app'] as String;
        _enabled[app] = m['enabled'] == true;
        _urls[app]?.text = (m['url'] ?? '') as String;
      }
      if (mounted) setState(() => _loaded = true);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  void _msg(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _save(String app) async {
    final enabled = _enabled[app] ?? false;
    final url = _urls[app]!.text.trim();
    if (enabled && !RegExp(r'^https?://', caseSensitive: false).hasMatch(url)) {
      _msg('أدخل رابطاً يبدأ بـ https://');
      return;
    }
    setState(() => _saving[app] = true);
    try {
      await Supabase.instance.client.rpc('admin_set_app_update',
          params: {'p_app': app, 'p_enabled': enabled, 'p_url': url});
      _msg(enabled ? 'تم إطلاق التحديث لـ${_apps[app]}' : 'تم إيقاف التحديث لـ${_apps[app]}');
    } catch (e) {
      _msg('تعذر الحفظ: $e');
    } finally {
      if (mounted) setState(() => _saving[app] = false);
    }
  }

  Widget _card(String app) {
    final enabled = _enabled[app] ?? false;
    final saving = _saving[app] == true;
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(_apps[app]!, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('إطلاق تحديث'),
            subtitle: Text(enabled ? 'التطبيق محجوب حتى يُحدَّث' : 'التطبيق يعمل بشكل طبيعي'),
            value: enabled,
            onChanged: saving ? null : (v) => setState(() => _enabled[app] = v),
          ),
          TextField(
            controller: _urls[app],
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(labelText: 'رابط التحديث (https://...)'),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: saving ? null : () => _save(app),
            child: Text(saving ? 'جارٍ الحفظ…' : 'حفظ'),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Center(
          child: _error == null
              ? const CircularProgressIndicator()
              : Text('تعذر التحميل: $_error', textAlign: TextAlign.center));
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [for (final app in _apps.keys) _card(app)],
    );
  }
}

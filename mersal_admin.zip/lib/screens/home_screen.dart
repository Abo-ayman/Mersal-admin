import 'dart:async';

import 'package:flutter/material.dart';

import '../core/logo.dart';
import '../data/admin_repository.dart';
import 'accounts_screen.dart';
import 'create_user_screen.dart';
import 'fees_screen.dart';
import 'login_screen.dart';
import 'stores_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = AdminRepository();
  int _index = 0;
  int _blocked = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadBlocked();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _loadBlocked());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadBlocked() async {
    try {
      final rows = await _repo.feeDrivers();
      final n = rows.where((r) => r['blocked'] == true).length;
      if (mounted) setState(() => _blocked = n);
    } catch (_) {}
  }

  Future<void> _logout() async {
    await _repo.signOut();
    if (!mounted) return;
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const AccountsScreen(),
      FeesScreen(onChanged: _loadBlocked),
      const StoresScreen(),
      const CreateUserScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const MersalLogo(markSize: 30, horizontal: true),
        actions: [IconButton(onPressed: _logout, icon: const Icon(Icons.logout), tooltip: 'خروج')],
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.people_outline), label: 'الحسابات'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: _blocked > 0,
              label: Text('$_blocked'),
              backgroundColor: Colors.red,
              child: const Icon(Icons.payments_outlined),
            ),
            label: 'الرسوم',
          ),
          const NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'المتاجر'),
          const NavigationDestination(icon: Icon(Icons.person_add_alt_1_outlined), label: 'إضافة حساب'),
        ],
      ),
    );
  }
}

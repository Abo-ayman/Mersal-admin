import 'dart:async';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import '../core/logo.dart';
import '../data/admin_repository.dart';
import 'accounts_screen.dart';
import 'active_orders_screen.dart';
import 'complaints_screen.dart';
import 'fees_screen.dart';
import 'login_screen.dart';
import 'more_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = AdminRepository();
  int _index = 0;
  int _blocked = 0;
  int _openComplaints = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadBadges();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _loadBadges());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadBadges() async {
    try {
      final rows = await _repo.feeDrivers();
      final n = rows.where((r) => r['blocked'] == true).length;
      if (mounted) setState(() => _blocked = n);
    } catch (_) {}
    try {
      final rows = await _repo.complaints();
      final n = rows.where((r) => r['status'] == 'open').length;
      if (mounted) setState(() => _openComplaints = n);
    } catch (_) {}
  }

  Future<void> _logout() async {
    await _repo.signOut();
    if (!mounted) return;
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const ActiveOrdersScreen(),
      const AccountsScreen(),
      FeesScreen(onChanged: _loadBadges),
      ComplaintsScreen(onChanged: _loadBadges),
      const MoreScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const MersalLogo(markSize: 30, horizontal: true),
        actions: [IconButton(onPressed: _logout, icon: const I3(Icons.logout), tooltip: 'خروج')],
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(icon: I3(Icons.local_shipping_outlined), label: 'الجارية'),
          const NavigationDestination(icon: I3(Icons.people_outline), label: 'الحسابات'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: _blocked > 0,
              label: Text('$_blocked'),
              backgroundColor: Colors.red,
              child: const I3(Icons.payments_outlined),
            ),
            label: 'الرسوم',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: _openComplaints > 0,
              label: Text('$_openComplaints'),
              backgroundColor: Colors.red,
              child: const I3(Icons.report_gmailerrorred_outlined),
            ),
            label: 'الشكاوى',
          ),
          const NavigationDestination(icon: I3(Icons.more_horiz), label: 'المزيد'),
        ],
      ),
    );
  }
}

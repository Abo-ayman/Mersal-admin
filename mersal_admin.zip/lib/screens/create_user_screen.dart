import 'dart:math';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../core/icon3d.dart';

import '../data/admin_repository.dart';
import 'store_location_screen.dart';

/// Create a driver, a taxi driver, or a seller account that comes with its own new store
/// (name, location and a first product, so the store shows in the customer app right away).
class CreateUserScreen extends StatefulWidget {
  const CreateUserScreen({super.key});

  @override
  State<CreateUserScreen> createState() => _CreateUserScreenState();
}

class _CreateUserScreenState extends State<CreateUserScreen> {
  final _repo = AdminRepository();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  String _role = 'driver';
  // seller: the new store and its first product
  final _storeName = TextEditingController();
  final _storeAddress = TextEditingController();
  final _productName = TextEditingController();
  final _productPrice = TextEditingController();
  final _productDesc = TextEditingController();
  LatLng? _storePoint;
  bool _busy = false;
  String? _error;

  num? _price() {
    const ar = '٠١٢٣٤٥٦٧٨٩';
    var t = _productPrice.text.trim();
    for (var i = 0; i < 10; i++) {
      t = t.replaceAll(ar[i], '$i');
    }
    return num.tryParse(t.replaceAll('٫', '.').replaceAll(',', '.'));
  }

  Future<void> _pickStorePoint() async {
    final p = await Navigator.of(context)
        .push<LatLng>(MaterialPageRoute(builder: (_) => StoreLocationScreen(initial: _storePoint)));
    if (p != null) setState(() => _storePoint = p);
  }

  void _generatePassword() {
    const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    setState(() => _pass.text = List.generate(10, (_) => chars[r.nextInt(chars.length)]).join());
  }

  Future<void> _create() async {
    if (_role == 'seller') {
      final price = _price();
      String? err;
      if (_storeName.text.trim().length < 2) {
        err = 'اكتب اسم المتجر';
      } else if (_storePoint == null) {
        err = 'حدد موقع المتجر على الخريطة';
      } else if (_productName.text.trim().length < 2) {
        err = 'اكتب اسم المنتج الأول';
      } else if (price == null || price <= 0) {
        err = 'اكتب سعراً صحيحاً للمنتج';
      }
      if (err != null) {
        setState(() => _error = err);
        return;
      }
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createUser(
        email: _email.text.trim(),
        password: _pass.text,
        fullName: _name.text.trim(),
        phone: _phone.text.trim().isEmpty ? null : _phone.text.trim(),
        role: _role,
        store: _role != 'seller'
            ? null
            : {
                'name': _storeName.text.trim(),
                'address': _storeAddress.text.trim(),
                'lat': _storePoint!.latitude,
                'lon': _storePoint!.longitude,
                'product': {
                  'name': _productName.text.trim(),
                  'price': _price(),
                  'description': _productDesc.text.trim(),
                },
              },
      );
      if (!mounted) return;
      final email = _email.text.trim();
      final pass = _pass.text;
      _name.clear();
      _email.clear();
      _phone.clear();
      _pass.clear();
      final storeName = _storeName.text.trim();
      final seller = _role == 'seller';
      _storeName.clear();
      _storeAddress.clear();
      _productName.clear();
      _productPrice.clear();
      _productDesc.clear();
      setState(() => _storePoint = null);
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('تم إنشاء الحساب'),
          content: SelectableText('${seller ? 'تم إنشاء متجر «$storeName» وهو ظاهر الآن للزبائن.\n\n' : ''}'
              'البريد: $email\nكلمة المرور: $pass\n\nسلّمهما لصاحب الحساب. لن تظهر كلمة المرور مرة أخرى.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))],
        ),
      );
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'driver', label: Text('سائق'), icon: I3(Icons.delivery_dining)),
            ButtonSegment(value: 'taxi_driver', label: Text('سائق تاكسي'), icon: I3(Icons.local_taxi)),
            ButtonSegment(value: 'seller', label: Text('حساب متجر'), icon: I3(Icons.storefront)),
          ],
          selected: {_role},
          onSelectionChanged: (s) => setState(() => _role = s.first),
        ),
        const SizedBox(height: 16),
        TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل *')),
        const SizedBox(height: 12),
        TextField(
          controller: _email,
          keyboardType: TextInputType.emailAddress,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(labelText: 'البريد الإلكتروني *'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'رقم الهاتف'),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _pass,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'كلمة المرور * (8 أحرف على الأقل)'),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filledTonal(
              onPressed: _generatePassword, icon: const I3(Icons.auto_fix_high), tooltip: 'توليد'),
        ]),
        if (_role == 'seller') ...[
          const SizedBox(height: 20),
          const Text('المتجر الجديد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          TextField(controller: _storeName, decoration: const InputDecoration(labelText: 'اسم المتجر *')),
          const SizedBox(height: 12),
          TextField(controller: _storeAddress, decoration: const InputDecoration(labelText: 'العنوان (وصف)')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _busy ? null : _pickStorePoint,
            icon: const Icon(Icons.place_outlined),
            label: Text(_storePoint == null ? 'حدد موقع المتجر على الخريطة *' : 'تم تحديد موقع المتجر ✓'),
          ),
          const SizedBox(height: 20),
          const Text('المنتج الأول', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const Text('يضيف التاجر صورته وباقي المنتجات من تطبيق التاجر',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 8),
          TextField(controller: _productName, decoration: const InputDecoration(labelText: 'اسم المنتج *')),
          const SizedBox(height: 12),
          TextField(
            controller: _productPrice,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(labelText: 'السعر *'),
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _productDesc,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'وصف المنتج (اختياري)')),
        ],
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: Colors.red)),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _busy ? null : _create,
          child: _busy
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('إنشاء الحساب'),
        ),
      ],
    );
  }
}

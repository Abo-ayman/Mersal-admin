import 'dart:math';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import '../data/admin_repository.dart';

/// Create a driver account, or a login account linked to a store.
class CreateUserScreen extends StatefulWidget {
  const CreateUserScreen({super.key});

  @override
  State<CreateUserScreen> createState() => _CreateUserScreenState();
}

class _CreateUserScreenState extends State<CreateUserScreen> {
  final _repo = AdminRepository();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  String _role = 'driver';
  List<Map<String, dynamic>> _stores = [];
  String? _storeId;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadStores();
  }

  Future<void> _loadStores() async {
    try {
      final s = await _repo.stores();
      if (mounted) setState(() => _stores = s);
    } catch (_) {}
  }

  void _generatePassword() {
    const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    setState(() => _pass.text = List.generate(10, (_) => chars[r.nextInt(chars.length)]).join());
  }

  Future<void> _create() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createUser(
        email: _email.text.trim(),
        password: _pass.text,
        fullName: _name.text.trim(),
        phone: _phone.text.trim().isEmpty ? null : _phone.text.trim(),
        role: _role,
        storeId: _role == 'seller' ? _storeId : null,
      );
      if (!mounted) return;
      final email = _email.text.trim();
      final pass = _pass.text;
      _name.clear();
      _email.clear();
      _phone.clear();
      _pass.clear();
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('تم إنشاء الحساب'),
          content: SelectableText('البريد: $email\nكلمة المرور: $pass\n\nسلّمهما لصاحب الحساب. لن تظهر كلمة المرور مرة أخرى.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))],
        ),
      );
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'driver', label: Text('سائق'), icon: I3(Icons.delivery_dining)),
            ButtonSegment(value: 'seller', label: Text('حساب متجر'), icon: I3(Icons.storefront)),
          ],
          selected: {_role},
          onSelectionChanged: (s) => setState(() => _role = s.first),
        ),
        const SizedBox(height: 16),
        TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل *')),
        const SizedBox(height: 12),
        TextField(
          controller: _email,
          keyboardType: TextInputType.emailAddress,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(labelText: 'البريد الإلكتروني *'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'رقم الهاتف'),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _pass,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'كلمة المرور * (8 أحرف على الأقل)'),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filledTonal(
              onPressed: _generatePassword, icon: const I3(Icons.auto_fix_high), tooltip: 'توليد'),
        ]),
        if (_role == 'seller') ...[
          const SizedBox(height: 12),
          if (_stores.isEmpty)
            const Text('لا توجد متاجر. أنشئ متجراً أولاً من تبويب «المتاجر».',
                style: TextStyle(color: Colors.orange))
          else
            DropdownButtonFormField<String>(
              value: _storeId,
              decoration: const InputDecoration(labelText: 'المتجر *'),
              items: [
                for (final s in _stores)
                  DropdownMenuItem(value: s['id'] as String, child: Text('${s['name']}')),
              ],
              onChanged: (v) => setState(() => _storeId = v),
            ),
        ],
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: Colors.red)),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _busy ? null : _create,
          child: _busy
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('إنشاء الحساب'),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/admin_repository.dart';
import 'order_chat_screen.dart';

class AccountDetailScreen extends StatefulWidget {
  final Map<String, dynamic> account;
  const AccountDetailScreen({super.key, required this.account});

  @override
  State<AccountDetailScreen> createState() => _AccountDetailScreenState();
}

class _AccountDetailScreenState extends State<AccountDetailScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _orders = _repo.accountOrders(widget.account['id']);
  late int _unpaid = (widget.account['unpaid_fees'] as num?)?.toInt() ?? 0;
  bool _busy = false;

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _settle() async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد السداد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('تسجيل سداد كل رسوم ${accountName(widget.account)} ($_unpaid رسوم)؟'),
          const SizedBox(height: 12),
          TextField(controller: note, decoration: const InputDecoration(hintText: 'ملاحظة (اختياري)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('تم السداد')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    try {
      final n = await _repo.settleFees(widget.account['id'],
          note: note.text.trim().isEmpty ? null : note.text.trim());
      _msg('سُجّل سداد $n رسوم');
      setState(() => _unpaid = 0);
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.account;
    final roles = (a['roles'] as List).cast<String>();
    final phone = a['phone'] as String?;
    return Scaffold(
      appBar: AppBar(title: Text(accountName(a))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Wrap(spacing: 6, children: [
                  for (final r in roles) Chip(label: Text(roleAr[r] ?? r)),
                ]),
                const SizedBox(height: 6),
                Text('البريد: ${a['email'] ?? '-'}', textDirection: TextDirection.ltr),
                Text('الهاتف: ${phone ?? '-'}'),
                Text('تاريخ الإنشاء: ${fmtDate(a['created_at'])}'),
                Text('طلبات كزبون: ${a['customer_orders']}   ·   كسائق: ${a['driver_orders']}'),
                if (phone != null && phone.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: OutlinedButton.icon(
                      onPressed: () => launchUrl(Uri.parse('tel:$phone'),
                          mode: LaunchMode.externalApplication),
                      icon: const Icon(Icons.call),
                      label: const Text('اتصال'),
                    ),
                  ),
              ]),
            ),
          ),
          if (roles.contains('driver') && _unpaid > 0) ...[
            const SizedBox(height: 12),
            Card(
              color: Colors.red.withValues(alpha: 0.06),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('رسوم الشركة غير المسدّدة: $_unpaid  (${a['unpaid_total']} ل.ت)',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  FilledButton(
                      onPressed: _busy ? null : _settle, child: const Text('تم السداد')),
                ]),
              ),
            ),
          ],
          const SizedBox(height: 16),
          const Text('سجل الطلبات',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _orders,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Padding(
                    padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
              }
              if (snap.hasError) return const Text('تعذر تحميل الطلبات');
              final list = snap.data!;
              if (list.isEmpty) return const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد طلبات'));
              return Column(children: [
                for (final o in list)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Card(
                      child: ListTile(
                        title: Text(
                          '#${o['order_number']} · ${o['item_name'] ?? (o['type'] == 'custom' ? 'طلب خاص' : 'طلب')}',
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          '${statusAr[o['status']] ?? o['status']} · '
                          '${o['as_role'] == 'driver' ? 'كسائق' : 'كزبون'}\n'
                          'الزبون: ${o['customer_name'] ?? '-'} · السائق: ${o['driver_name'] ?? '-'}\n'
                          'الإجمالي ${o['total']} ل.ت · ${fmtDate(o['created_at'])}',
                        ),
                        isThreeLine: true,
                        trailing: (o['message_count'] as num) > 0
                            ? Badge(
                                label: Text('${o['message_count']}'),
                                child: const Icon(Icons.chat_bubble_outline),
                              )
                            : null,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => OrderChatScreen(order: o))),
                      ),
                    ),
                  ),
              ]);
            },
          ),
        ],
      ),
    );
  }
}

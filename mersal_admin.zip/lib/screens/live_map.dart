import 'dart:async';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';

/// Live position of the driver while the order is on its way (refreshes every 5 seconds).
/// The server only returns the position to the order's customer and only while the order
/// is "on the way" / "arrived".
class LiveDriverMap extends StatefulWidget {
  final String orderId;
  final String status;
  final double? customerLat;
  final double? customerLon;
  final bool fullScreen;
  const LiveDriverMap({
    super.key,
    required this.orderId,
    required this.status,
    this.customerLat,
    this.customerLon,
    this.fullScreen = false,
  });

  @override
  State<LiveDriverMap> createState() => _LiveDriverMapState();
}

class _LiveDriverMapState extends State<LiveDriverMap> {
  final _map = MapController();
  Timer? _timer;
  LatLng? _driver;
  DateTime? _updatedAt;
  String? _status; // latest order status reported by the server
  bool _loaded = false;

  LatLng? get _customer => (widget.customerLat != null && widget.customerLon != null)
      ? LatLng(widget.customerLat!, widget.customerLon!)
      : null;

  @override
  void initState() {
    super.initState();
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _poll() async {
    try {
      final res = await Supabase.instance.client
          .rpc('order_driver_location', params: {'p_order': widget.orderId});
      final rows = res as List;
      if (!mounted) return;
      if (rows.isEmpty) {
        setState(() => _loaded = true);
        return;
      }
      final r = Map<String, dynamic>.from(rows.first as Map);
      setState(() {
        _driver = LatLng((r['lat'] as num).toDouble(), (r['lon'] as num).toDouble());
        _updatedAt = DateTime.tryParse('${r['updated_at']}');
        _status = r['st']?.toString();
        _loaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  void _fit() {
    final pts = [if (_driver != null) _driver!, if (_customer != null) _customer!];
    if (pts.length < 2) return;
    try {
      _map.fitCamera(CameraFit.bounds(
          bounds: LatLngBounds.fromPoints(pts),
          padding: const EdgeInsets.all(56),
          maxZoom: 17));
    } catch (_) {}
  }

  String _distanceText() {
    if (_driver == null || _customer == null) return '';
    final m = const Distance().as(LengthUnit.Meter, _driver!, _customer!);
    return m >= 1000 ? 'على بعد ${(m / 1000).toStringAsFixed(1)} كم' : 'على بعد ${m.round()} متراً';
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const Padding(
          padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
    }
    if (_driver == null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.line)),
        child: const Row(children: [
          I3(Icons.location_searching, color: Brand.primary),
          SizedBox(width: 10),
          Expanded(child: Text('بانتظار موقع السائق… سيظهر على الخريطة بمجرد بدء مشاركته.')),
        ]),
      );
    }

    final age = _updatedAt == null ? null : DateTime.now().difference(_updatedAt!).inSeconds.abs();
    final stale = age != null && age > 60;
    final pts = [_driver!, if (_customer != null) _customer!];
    final fit = pts.length >= 2
        ? CameraFit.bounds(
            bounds: LatLngBounds.fromPoints(pts),
            padding: const EdgeInsets.all(56),
            maxZoom: 17)
        : null;

    final mapStack = Stack(children: [
            FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: _driver!,
                initialZoom: 16,
                initialCameraFit: fit,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.mersal.admin',
                ),
                MarkerLayer(markers: [
                  if (_customer != null)
                    Marker(
                      point: _customer!,
                      width: 44,
                      height: 44,
                      child: const I3(Icons.location_on, size: 42, color: Colors.red),
                    ),
                  Marker(
                    point: _driver!,
                    width: 46,
                    height: 46,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Brand.accent,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                      ),
                      child: const I3(Icons.delivery_dining, size: 24, color: Colors.white),
                    ),
                  ),
                ]),
              ],
            ),
            Positioned(
              right: 10,
              bottom: 10,
              child: FloatingActionButton.small(
                heroTag: null,
                onPressed: _fit,
                child: const I3(Icons.center_focus_strong),
              ),
            ),
          ]);

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const I3(Icons.delivery_dining, color: Brand.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            (_status ?? widget.status) == 'arrived'
                ? 'السائق وصل إلى موقعك'
                : 'السائق ${_distanceText()}',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        Text(stale ? 'الاتصال متقطع' : 'مباشر',
            style: TextStyle(color: stale ? Colors.orange : Colors.green, fontSize: 12)),
      ]),
      const SizedBox(height: 8),
      widget.fullScreen
          ? Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: mapStack))
          : ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(height: 260, child: mapStack)),
    ]);
  }
}

import 'package:flutter/material.dart';

import '../core/logo.dart';
import '../data/admin_repository.dart';
import 'home_screen.dart';
import 'login_screen.dart';

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});

  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> {
  @override
  void initState() {
    super.initState();
    _route();
  }

  Future<void> _route() async {
    final repo = AdminRepository();
    Widget next = const LoginScreen();
    try {
      if (repo.signedIn) {
        if (await repo.isAdmin()) {
          next = const HomeScreen();
        } else {
          await repo.signOut();
        }
      }
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => next));
  }

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: MersalLogo(markSize: 100)));
}

import 'package:flutter/material.dart';
import '../core/icon3d.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../data/admin_repository.dart';

/// Drivers with unpaid company fees. Those who reached the limit cannot accept orders
/// until "تم السداد" is pressed.
class FeesScreen extends StatefulWidget {
  final VoidCallback? onChanged;
  const FeesScreen({super.key, this.onChanged});

  @override
  State<FeesScreen> createState() => _FeesScreenState();
}

class _FeesScreenState extends State<FeesScreen> {
  final _repo = AdminRepository();
  Map<String, String> _totals = {}; // driver id -> "125 ل.س + 40 ل.ت"
  late Future<List<Map<String, dynamic>>> _future = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await _repo.feeDrivers();
    try {
      _totals = await _repo.feeTotalsText();
    } catch (_) {}
    return rows;
  }

  String _totalFor(Map<String, dynamic> d) => _totals['${d['driver_id']}'] ?? '${d['unpaid_total']} ل.ت';

  void _reload() {
    setState(() => _future = _load());
    widget.onChanged?.call();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _settle(Map<String, dynamic> d) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد السداد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('تسجيل سداد ${d['unpaid_count']} رسوم بقيمة ${_totalFor(d)} للسائق '
              '${d['full_name'] ?? ''}؟ سيتمكن بعدها من قبول الطلبات.'),
          const SizedBox(height: 12),
          TextField(controller: note, decoration: const InputDecoration(hintText: 'ملاحظة (اختياري)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('تم السداد')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final n = await _repo.settleFees(d['driver_id'],
          note: note.text.trim().isEmpty ? null : note.text.trim());
      _msg('سُجّل سداد $n رسوم');
    } catch (e) {
      _msg(friendlyError(e));
    }
    _reload();
  }

  Widget _card(Map<String, dynamic> d) {
    final blocked = d['blocked'] == true;
    final phone = d['phone'] as String?;
    return Card(
      color: blocked ? Colors.red.withValues(alpha: 0.06) : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text('${d['full_name'] ?? d['email']}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            if (blocked)
              const Chip(
                  label: Text('موقوف عن القبول'),
                  backgroundColor: Color(0x22FF0000),
                  side: BorderSide.none),
          ]),
          Text('رسوم غير مسدّدة: ${d['unpaid_count']} من ${d['fee_limit']}  ·  ${_totalFor(d)}'),
          Text('أقدم رسوم: ${fmtDate(d['oldest_unpaid'])}'),
          if (phone != null && phone.isNotEmpty) Text('الهاتف: $phone'),
          const SizedBox(height: 8),
          Row(children: [
            if (phone != null && phone.isNotEmpty)
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () =>
                      launchUrl(Uri.parse('tel:$phone'), mode: LaunchMode.externalApplication),
                  icon: const I3(Icons.call),
                  label: const Text('اتصال'),
                ),
              ),
            if (phone != null && phone.isNotEmpty) const SizedBox(width: 8),
            Expanded(
              child: FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(44)),
                  onPressed: () => _settle(d),
                  child: const Text('تم السداد')),
            ),
          ]),
        ]),
      ),
    );
  }

  /// Customers with unpaid taxi cancellation fees. Pressing "تم السداد" settles them and reopens the account.
  Future<List<Map<String, dynamic>>> _customerFees() async {
    final rows = await Supabase.instance.client.rpc('admin_customer_fees') as List;
    return rows.map((r) => Map<String, dynamic>.from(r as Map)).toList();
  }

  Widget _customerFeesSection() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _customerFees(),
      builder: (context, snap) {
        final rows = snap.data ?? const <Map<String, dynamic>>[];
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('زبائن عليهم رسوم إلغاء تاكسي (${rows.length})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (rows.isEmpty) const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('لا أحد حالياً')),
          for (final r in rows) Padding(padding: const EdgeInsets.only(bottom: 8), child: _customerCard(r)),
        ]);
      },
    );
  }

  Widget _customerCard(Map<String, dynamic> r) {
    final over = r['over_week'] == true;
    return Card(
      color: over ? Colors.red.withValues(alpha: 0.06) : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${r['customer_name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('الهاتف: ${r['phone'] ?? '-'}', textDirection: TextDirection.ltr),
          Text('${r['cnt']} رسوم · ${r['total']} ${r['currency_symbol'] ?? ''}'),
          if (over)
            const Text('مضى أكثر من أسبوع، الحساب موقوف حتى السداد',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          FilledButton(onPressed: () => _settleCustomer(r), child: const Text('تم السداد')),
        ]),
      ),
    );
  }

  Future<void> _settleCustomer(Map<String, dynamic> r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد السداد'),
        content: Text('تسجيل سداد رسوم ${r['customer_name']} بقيمة ${r['total']} ${r['currency_symbol'] ?? ''}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('تم السداد')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Supabase.instance.client.rpc('admin_settle_customer_fees', params: {'p_customer': r['customer_id']});
      _msg('تم تسجيل السداد وفتح الحساب');
    } catch (e) {
      _msg('تعذر التنفيذ: $e');
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => _reload(),
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ListView(children: [
              const SizedBox(height: 100),
              const Center(child: Text('تعذر التحميل')),
              Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
            ]);
          }
          final all = snap.data!;
          final blocked = all.where((d) => d['blocked'] == true).toList();
          final others = all.where((d) => d['blocked'] != true).toList();
          if (all.isEmpty) {
            return ListView(padding: const EdgeInsets.all(16), children: [
              const Center(child: Text('لا توجد رسوم غير مسدّدة للسائقين')),
              const SizedBox(height: 16),
              _customerFeesSection(),
            ]);
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('وصلوا الحد (${blocked.length})',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              if (blocked.isEmpty) const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('لا أحد حالياً')),
              for (final d in blocked) Padding(padding: const EdgeInsets.only(bottom: 8), child: _card(d)),
              const SizedBox(height: 12),
              Text('عليهم رسوم لم تصل للحد (${others.length})',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final d in others) Padding(padding: const EdgeInsets.only(bottom: 8), child: _card(d)),
              const SizedBox(height: 24),
              _customerFeesSection(),
            ],
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/admin_repository.dart';
import 'live_map.dart';
import 'live_tracking_screen.dart';
import 'order_chat_screen.dart';

/// Admin view of an ongoing order: parties, status, live map and chat.
class AdminOrderScreen extends StatelessWidget {
  final Map<String, dynamic> order;
  const AdminOrderScreen({super.key, required this.order});

  Future<void> _call(String? phone) async {
    if (phone == null || phone.isEmpty) return;
    await launchUrl(Uri.parse('tel:$phone'), mode: LaunchMode.externalApplication);
  }

  Widget _party(String title, String? name, String? phone) => Card(
        child: ListTile(
          title: Text('$title: ${name ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(phone ?? 'لا يوجد رقم'),
          trailing: (phone == null || phone.isEmpty)
              ? null
              : IconButton.filledTonal(onPressed: () => _call(phone), icon: const Icon(Icons.call)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final status = '${order['status']}';
    final live = status == 'on_the_way' || status == 'arrived';
    return Scaffold(
      appBar: AppBar(title: Text('طلب #${order['order_number']}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${order['item_name'] ?? 'طلب'}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('الحالة: ${statusAr[status] ?? status}'),
                Text('الإجمالي: ${order['total']} ${order['currency_symbol'] ?? 'ل.ت'} (توصيل ${order['delivery_total']})'),
                Text('العنوان: ${order['delivery_address'] ?? '-'}'),
                Text('أُنشئ: ${fmtDate(order['created_at'])}'),
              ]),
            ),
          ),
          _party('الزبون', order['customer_name'] as String?, order['customer_phone'] as String?),
          _party('السائق', order['driver_name'] as String?, order['driver_phone'] as String?),
          const SizedBox(height: 12),
          if (live) ...[
            LiveDriverMap(
              orderId: order['id'],
              status: status,
              customerLat: (order['delivery_lat'] as num?)?.toDouble(),
              customerLon: (order['delivery_lon'] as num?)?.toDouble(),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => LiveTrackingScreen(order: order))),
              icon: const Icon(Icons.fullscreen),
              label: const Text('عرض الخريطة بملء الشاشة'),
            ),
          ] else
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(14)),
              child: const Text('التتبع الحي يبدأ عندما يخرج السائق بالطلب (حالة «في الطريق»).'),
            ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => OrderChatScreen(order: order))),
            icon: const Icon(Icons.chat_bubble_outline),
            label: Text('المحادثة (${order['message_count'] ?? 0})'),
          ),
        ],
      ),
    );
  }
}

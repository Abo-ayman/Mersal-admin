import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import '../data/admin_repository.dart';

/// Custom notification to all customers, all drivers, or everyone (offers, announcements).
class BroadcastScreen extends StatefulWidget {
  const BroadcastScreen({super.key});

  @override
  State<BroadcastScreen> createState() => _BroadcastScreenState();
}

class _BroadcastScreenState extends State<BroadcastScreen> {
  final _repo = AdminRepository();
  final _title = TextEditingController();
  final _body = TextEditingController();
  String _audience = 'customers';
  bool _busy = false;
  String? _error;
  late Future<List<Map<String, dynamic>>> _history = _repo.broadcasts();

  static const _audienceAr = {'customers': 'الزبائن', 'drivers': 'السائقون', 'all': 'الجميع'};

  Future<void> _send() async {
    final title = _title.text.trim();
    final body = _body.text.trim();
    if (title.isEmpty || body.isEmpty) {
      setState(() => _error = 'اكتب عنوان الإشعار ونصّه');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد الإرسال'),
        content: Text('سيصل هذا الإشعار إلى «${_audienceAr[_audience]}» الذين فتحوا التطبيق وسمحوا بالإشعارات. لا يمكن التراجع بعد الإرسال.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('إرسال')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final n = await _repo.sendBroadcast(title, body, _audience);
      if (!mounted) return;
      _title.clear();
      _body.clear();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('أُرسل الإشعار إلى $n مستخدم')));
      setState(() => _history = _repo.broadcasts());
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'customers', label: Text('الزبائن')),
            ButtonSegment(value: 'drivers', label: Text('السائقون')),
            ButtonSegment(value: 'all', label: Text('الجميع')),
          ],
          selected: {_audience},
          onSelectionChanged: (s) => setState(() => _audience = s.first),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _title,
          maxLength: 80,
          decoration: const InputDecoration(labelText: 'عنوان الإشعار *'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _body,
          maxLength: 300,
          maxLines: 4,
          decoration: const InputDecoration(labelText: 'نص الإشعار *'),
        ),
        if (_error != null) ...[
          const SizedBox(height: 8),
          Text(_error!, style: const TextStyle(color: Colors.red)),
        ],
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _busy ? null : _send,
          icon: const I3(Icons.campaign_outlined),
          label: _busy
              ? const SizedBox(
                  height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('إرسال الإشعار'),
        ),
        const SizedBox(height: 24),
        const Text('آخر الإشعارات المرسلة',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: _history,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
            }
            if (snap.hasError) return const Text('تعذر تحميل السجل');
            final list = snap.data!;
            if (list.isEmpty) return const Text('لم تُرسل إشعارات بعد');
            return Column(children: [
              for (final b in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Card(
                    child: ListTile(
                      title: Text('${b['title']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${b['body']}\n${_audienceAr[b['audience']] ?? b['audience']} · '
                          '${b['recipients']} مستخدم · ${fmtDate(b['created_at'])}'),
                      isThreeLine: true,
                    ),
                  ),
                ),
            ]);
          },
        ),
      ],
    );
  }
}

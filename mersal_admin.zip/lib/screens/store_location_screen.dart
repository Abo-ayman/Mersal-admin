import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../core/theme.dart';

/// Pick a store's position: move the map under the pin and confirm. Returns the [LatLng].
class StoreLocationScreen extends StatefulWidget {
  final LatLng? initial;
  const StoreLocationScreen({super.key, this.initial});

  @override
  State<StoreLocationScreen> createState() => _StoreLocationScreenState();
}

class _StoreLocationScreenState extends State<StoreLocationScreen> {
  final _map = MapController();
  // Jarabulus city centre when the store has no position yet.
  late final LatLng _start = widget.initial ?? const LatLng(36.8169, 38.0156);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('موقع المتجر')),
      body: Stack(children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(initialCenter: _start, initialZoom: 16),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.mersal.admin',
            ),
          ],
        ),
        const IgnorePointer(
          child: Center(
            child: Padding(
              padding: EdgeInsets.only(bottom: 40),
              child: Icon(Icons.location_pin, size: 48, color: Brand.primary),
            ),
          ),
        ),
        Positioned(
          left: 16,
          right: 16,
          bottom: 24,
          child: FilledButton(
            onPressed: () => Navigator.pop(context, _map.camera.center),
            child: const Text('تأكيد الموقع'),
          ),
        ),
      ]),
    );
  }
}

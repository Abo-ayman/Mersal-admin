import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import 'broadcast_screen.dart';
import 'create_user_screen.dart';
import 'offers_screen.dart';
import 'stores_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String title, String sub, Widget page) => Card(
          child: ListTile(
            leading: I3(icon),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(sub),
            trailing: const I3(Icons.chevron_left),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: page))),
          ),
        );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        tile(Icons.local_offer_outlined, 'العروض', 'عروض تظهر في تطبيق الزبون لفترة محددة', const OffersScreen()),
        const SizedBox(height: 8),
        tile(Icons.campaign_outlined, 'إشعار عام', 'إرسال إشعار مخصص إلى الزبائن أو السائقين', const BroadcastScreen()),
        const SizedBox(height: 8),
        tile(Icons.storefront_outlined, 'المتاجر', 'عرض المتاجر وإضافة متجر جديد', const StoresScreen()),
        const SizedBox(height: 8),
        tile(Icons.person_add_alt_1_outlined, 'إضافة حساب', 'إنشاء حساب سائق أو حساب متجر', const CreateUserScreen()),
      ],
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import '../core/theme.dart';
import '../data/admin_repository.dart';
import 'admin_order_screen.dart';

/// Ongoing orders (waiting for a driver, being prepared, on the way, arrived).
class ActiveOrdersScreen extends StatefulWidget {
  const ActiveOrdersScreen({super.key});

  @override
  State<ActiveOrdersScreen> createState() => _ActiveOrdersScreenState();
}

class _ActiveOrdersScreenState extends State<ActiveOrdersScreen> {
  final _repo = AdminRepository();
  Timer? _timer;
  List<Map<String, dynamic>> _orders = [];
  bool _loaded = false;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await _repo.activeOrders();
      if (!mounted) return;
      setState(() {
        _orders = rows;
        _loaded = true;
        _error = false;
      });
    } catch (_) {
      if (mounted) setState(() => _error = !_loaded);
    }
  }

  /// True when the order is on the way but no fresh GPS point arrived.
  bool _noGps(Map<String, dynamic> o) {
    if (o['status'] != 'on_the_way' && o['status'] != 'arrived') return false;
    final at = DateTime.tryParse('${o['last_location_at']}');
    return at == null || DateTime.now().difference(at).inSeconds.abs() > 90;
  }

  Color _color(String s) => switch (s) {
        'on_the_way' => Brand.accent,
        'arrived' => Colors.green,
        'pending_driver' => Colors.orange,
        _ => Brand.primary,
      };

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Center(
          child: _error
              ? TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))
              : const CircularProgressIndicator());
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: _orders.isEmpty
          ? ListView(children: const [
              SizedBox(height: 120),
              Center(child: Text('لا توجد طلبات جارية الآن')),
            ])
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final o = _orders[i];
                final status = '${o['status']}';
                final live = status == 'on_the_way' || status == 'arrived';
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    title: Text(
                      '#${o['order_number']} · ${o['item_name'] ?? 'طلب'}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      'الزبون: ${o['customer_name'] ?? '-'}\n'
                      'السائق: ${o['driver_name'] ?? 'لم يُقبل بعد'}\n'
                      '${statusAr[status] ?? status} · ${o['total']} ${o['currency_symbol'] ?? 'ل.ت'}',
                    ),
                    isThreeLine: true,
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        I3(live ? Icons.my_location : Icons.chevron_left, color: live ? Colors.green : null),
                        if (_noGps(o))
                          const Text('بلا GPS', style: TextStyle(color: Colors.orange, fontSize: 11)),
                      ],
                    ),
                    onTap: () async {
                      await Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => AdminOrderScreen(order: o)));
                      _load();
                    },
                  ),
                );
              },
            ),
    );
  }
}

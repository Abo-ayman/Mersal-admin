import 'package:flutter/material.dart';

import '../data/admin_repository.dart';

class CreateStoreScreen extends StatefulWidget {
  const CreateStoreScreen({super.key});

  @override
  State<CreateStoreScreen> createState() => _CreateStoreScreenState();
}

class _CreateStoreScreenState extends State<CreateStoreScreen> {
  final _repo = AdminRepository();
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _newCategory = TextEditingController();
  List<Map<String, dynamic>> _categories = [];
  String? _categoryId;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      final c = await _repo.storeCategories();
      if (mounted) setState(() => _categories = c);
    } catch (_) {}
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'اسم المتجر مطلوب');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      var categoryId = _categoryId;
      if (_newCategory.text.trim().isNotEmpty) {
        categoryId = await _repo.createStoreCategory(_newCategory.text.trim());
      }
      await _repo.createStore(
        name: _name.text.trim(),
        description: _desc.text.trim(),
        phone: _phone.text.trim(),
        address: _address.text.trim(),
        categoryId: categoryId,
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('متجر جديد')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم المتجر *')),
          const SizedBox(height: 12),
          TextField(
              controller: _desc,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'وصف المتجر')),
          const SizedBox(height: 12),
          if (_categories.isNotEmpty)
            DropdownButtonFormField<String>(
              value: _categoryId,
              decoration: const InputDecoration(labelText: 'القسم'),
              items: [
                for (final c in _categories)
                  DropdownMenuItem(value: c['id'] as String, child: Text('${c['name']}')),
              ],
              onChanged: (v) => setState(() => _categoryId = v),
            ),
          if (_categories.isNotEmpty) const SizedBox(height: 12),
          TextField(
              controller: _newCategory,
              decoration: const InputDecoration(
                  labelText: 'أو أنشئ قسماً جديداً (اختياري)', hintText: 'مثال: مطاعم')),
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'هاتف المتجر')),
          const SizedBox(height: 12),
          TextField(controller: _address, decoration: const InputDecoration(labelText: 'العنوان')),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('حفظ المتجر'),
          ),
        ],
      ),
    );
  }
}

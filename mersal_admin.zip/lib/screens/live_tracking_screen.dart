import 'package:flutter/material.dart';

import 'live_map.dart';

/// Full-screen live map of one order's driver (admin view).
class LiveTrackingScreen extends StatelessWidget {
  final Map<String, dynamic> order;
  const LiveTrackingScreen({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تتبع الطلب #${order['order_number']}')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: LiveDriverMap(
          orderId: order['id'],
          status: '${order['status']}',
          customerLat: (order['delivery_lat'] as num?)?.toDouble(),
          customerLon: (order['delivery_lon'] as num?)?.toDouble(),
          fullScreen: true,
        ),
      ),
    );
  }
}

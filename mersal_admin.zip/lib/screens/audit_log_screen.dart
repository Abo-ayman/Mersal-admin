import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Recent sensitive actions: app update changes, public broadcasts and company fee settlements.
class AuditLogScreen extends StatefulWidget {
  const AuditLogScreen({super.key});

  @override
  State<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _AuditLogScreenState extends State<AuditLogScreen> {
  static const _tables = {
    'app_updates': 'تحديث التطبيق',
    'broadcasts': 'إشعار عام',
    'company_fees': 'رسوم الشركة',
  };
  static const _actions = {'INSERT': 'إضافة', 'UPDATE': 'تعديل', 'DELETE': 'حذف'};

  List<Map<String, dynamic>>? _rows;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await Supabase.instance.client
          .rpc('admin_audit_log_list', params: {'p_limit': 100}) as List;
      if (mounted) {
        setState(() {
          _rows = rows.map((r) => Map<String, dynamic>.from(r as Map)).toList();
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  String _when(String iso) {
    final d = DateTime.parse(iso).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.day}/${d.month} ${two(d.hour)}:${two(d.minute)}';
  }

  String _summary(Map<String, dynamic> row) {
    final detail = row['detail'] as Map<String, dynamic>?;
    final after = detail?['after'] as Map<String, dynamic>?;
    if (after == null) return '';
    switch (row['table_name']) {
      case 'app_updates':
        final on = after['enabled'] == true ? 'مفعّل' : 'متوقف';
        return '$on · أقل رقم نسخة: ${after['min_build']}';
      case 'broadcasts':
        return '${after['title']} · ${after['audience']}';
      case 'company_fees':
        return 'الحالة: ${after['status']} · المبلغ: ${after['fee_amount']}';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    if (rows == null) {
      return Center(
          child: _error == null
              ? const CircularProgressIndicator()
              : Text('تعذر التحميل: $_error', textAlign: TextAlign.center));
    }
    if (rows.isEmpty) return const Center(child: Text('لا توجد عمليات مسجلة بعد'));
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: rows.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) {
          final r = rows[i];
          final table = _tables[r['table_name']] ?? r['table_name'];
          final action = _actions[r['action']] ?? r['action'];
          return Card(
            child: ListTile(
              title: Text('$action · $table',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text([
                if ((r['row_key'] ?? '').toString().isNotEmpty) r['row_key'].toString(),
                _summary(r),
              ].where((s) => s.isNotEmpty).join('\n')),
              isThreeLine: true,
              trailing: Text(_when(r['created_at'] as String),
                  style: const TextStyle(fontSize: 11, color: Colors.black54)),
            ),
          );
        },
      ),
    );
  }
}

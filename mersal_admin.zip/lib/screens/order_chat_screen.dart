import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/admin_repository.dart';

/// Read-only view of an order and its chat.
class OrderChatScreen extends StatefulWidget {
  final Map<String, dynamic> order;
  const OrderChatScreen({super.key, required this.order});

  @override
  State<OrderChatScreen> createState() => _OrderChatScreenState();
}

class _OrderChatScreenState extends State<OrderChatScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.orderMessages(widget.order['id']);

  @override
  Widget build(BuildContext context) {
    final o = widget.order;
    return Scaffold(
      appBar: AppBar(
        title: Text('طلب #${o['order_number']}'),
        actions: [
          IconButton(
              onPressed: () => setState(() => _future = _repo.orderMessages(o['id'])),
              icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Brand.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${o['item_name'] ?? 'طلب'}',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            Text('الحالة: ${statusAr[o['status']] ?? o['status']}'),
            Text('الزبون: ${o['customer_name'] ?? '-'}  ·  السائق: ${o['driver_name'] ?? '-'}'),
            Text('الإجمالي: ${o['total']} ${o['currency_symbol'] ?? 'ل.ت'} (توصيل ${o['delivery_total']})'),
          ]),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text('المحادثة (للاطلاع فقط)',
                  style: TextStyle(fontWeight: FontWeight.w800))),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return const Center(child: Text('تعذر تحميل المحادثة'));
              final msgs = snap.data!;
              if (msgs.isEmpty) return const Center(child: Text('لا توجد رسائل في هذا الطلب'));
              return ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  final isDriver = m['sender_role'] == 'driver';
                  return Align(
                    alignment: isDriver
                        ? AlignmentDirectional.centerStart
                        : AlignmentDirectional.centerEnd,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(10),
                      constraints:
                          BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                      decoration: BoxDecoration(
                        color: isDriver ? Brand.primary.withValues(alpha: 0.12) : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Brand.line),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${m['sender_name']} · ${isDriver ? 'سائق' : 'زبون'}',
                            style: const TextStyle(fontSize: 11, color: Colors.black54)),
                        Text('${m['body']}'),
                        Text(fmtDate(m['created_at']),
                            style: const TextStyle(fontSize: 10, color: Colors.black45)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

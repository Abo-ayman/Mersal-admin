import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';
import 'order_chat_screen.dart';

/// All trips with their routes and the order chat, for the admin.
class AdminTripsScreen extends StatefulWidget {
  const AdminTripsScreen({super.key});

  @override
  State<AdminTripsScreen> createState() => _AdminTripsScreenState();
}

class _AdminTripsScreenState extends State<AdminTripsScreen> {
  late final Future<List<Map<String, dynamic>>> _trips = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .rpc('admin_trips', params: {'p_limit': 200}) as List;
    return rows.map((r) => Map<String, dynamic>.from(r as Map)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _trips,
      builder: (_, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return Center(child: Text('تعذر التحميل: ${snap.error}'));
        final trips = snap.data ?? const <Map<String, dynamic>>[];
        if (trips.isEmpty) return const Center(child: Text('لا توجد رحلات'));
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: trips.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final t = trips[i];
            final km = ((t['distance_m'] ?? 0) as num) / 1000;
            return Card(
              child: ListTile(
                leading: const Icon(Icons.route_rounded, color: Brand.primary),
                title: Text('طلب #${t['order_number']} · ${t['customer_name']}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('السائق: ${t['driver_name']}\n'
                    '${km.toStringAsFixed(1)} كم · ${t['status']} · ${t['total'] ?? ''} ${t['currency_symbol'] ?? ''}'),
                isThreeLine: true,
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => AdminTripDetailScreen(trip: t))),
              ),
            );
          },
        );
      },
    );
  }
}

/// One trip: its route on the map, and the chat of its order.
class AdminTripDetailScreen extends StatelessWidget {
  final Map<String, dynamic> trip;
  const AdminTripDetailScreen({super.key, required this.trip});

  Future<List<LatLng>> _route() async {
    final rows = await Supabase.instance.client
        .rpc('trip_route', params: {'p_trip': trip['trip_id']}) as List;
    return rows.map((r) {
      final m = r as Map;
      return LatLng((m['latitude'] as num).toDouble(), (m['longitude'] as num).toDouble());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('طلب #${trip['order_number']}'),
        actions: [
          IconButton(
            tooltip: 'المحادثة',
            icon: const Icon(Icons.chat_outlined),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => OrderChatScreen(
                    order: {'id': trip['order_id'], 'order_number': trip['order_number']}))),
          ),
        ],
      ),
      body: FutureBuilder<List<LatLng>>(
        future: _route(),
        builder: (_, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final pts = snap.data ?? const <LatLng>[];
          if (snap.hasError || pts.isEmpty) {
            return const Center(child: Text('لا يوجد مسار مسجّل لهذه الرحلة'));
          }
          return FlutterMap(
            options: MapOptions(
              initialCameraFit:
                  CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.all(48)),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.mersal.admin',
              ),
              PolylineLayer(
                polylines: [Polyline(points: pts, strokeWidth: 5, color: Brand.primary)],
              ),
              MarkerLayer(markers: [
                Marker(
                    point: pts.first,
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.trip_origin, color: Colors.green)),
                Marker(
                    point: pts.last,
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.flag, color: Colors.red)),
              ]),
            ],
          );
        },
      ),
    );
  }
}

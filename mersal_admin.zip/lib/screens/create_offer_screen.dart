import 'package:flutter/material.dart';
import '../core/icon3d.dart';

import '../data/admin_repository.dart';

class CreateOfferScreen extends StatefulWidget {
  const CreateOfferScreen({super.key});

  @override
  State<CreateOfferScreen> createState() => _CreateOfferScreenState();
}

class _CreateOfferScreenState extends State<CreateOfferScreen> {
  final _repo = AdminRepository();
  final _title = TextEditingController();
  final _body = TextEditingController();
  List<Map<String, dynamic>> _cities = [];
  String? _cityId; // null = every city
  DateTime? _startsAt; // null = now
  DateTime _expiresAt = DateTime.now().add(const Duration(days: 7));
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.cities().then((c) {
      if (mounted) setState(() => _cities = c);
    }, onError: (_) {});
  }

  Future<DateTime?> _pick(DateTime initial) async {
    final d = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (d == null || !mounted) return null;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(initial));
    if (t == null) return null;
    return DateTime(d.year, d.month, d.day, t.hour, t.minute);
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty || _body.text.trim().isEmpty) {
      setState(() => _error = 'اكتب عنوان العرض ونصّه');
      return;
    }
    final start = _startsAt ?? DateTime.now();
    if (!_expiresAt.isAfter(start)) {
      setState(() => _error = 'تاريخ الانتهاء يجب أن يكون بعد تاريخ البداية');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createOffer(
        title: _title.text.trim(),
        body: _body.text.trim(),
        expiresAt: _expiresAt,
        startsAt: _startsAt,
        cityId: _cityId,
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عرض جديد')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _title,
            maxLength: 80,
            decoration: const InputDecoration(labelText: 'عنوان العرض *'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _body,
            maxLength: 500,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'نص العرض *'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _cityId,
            decoration: const InputDecoration(labelText: 'يظهر في'),
            items: [
              const DropdownMenuItem<String?>(value: null, child: Text('كل المدن')),
              for (final c in _cities)
                DropdownMenuItem<String?>(value: c['id'] as String, child: Text('${c['name']}')),
            ],
            onChanged: (v) => setState(() => _cityId = v),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () async {
              final d = await _pick(_startsAt ?? DateTime.now());
              if (d != null) setState(() => _startsAt = d);
            },
            icon: const I3(Icons.play_arrow),
            label: Text(_startsAt == null ? 'يبدأ الآن (اضغط لجدولة البداية)' : 'يبدأ: ${fmtDate(_startsAt!.toIso8601String())}'),
          ),
          if (_startsAt != null)
            TextButton(onPressed: () => setState(() => _startsAt = null), child: const Text('إلغاء الجدولة (ابدأ الآن)')),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              final d = await _pick(_expiresAt);
              if (d != null) setState(() => _expiresAt = d);
            },
            icon: const I3(Icons.event),
            label: Text('ينتهي: ${fmtDate(_expiresAt.toIso8601String())}'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('نشر العرض'),
          ),
        ],
      ),
    );
  }
}

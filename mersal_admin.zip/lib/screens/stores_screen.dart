import 'package:flutter/material.dart';

import '../data/admin_repository.dart';
import 'create_store_screen.dart';

class StoresScreen extends StatefulWidget {
  const StoresScreen({super.key});

  @override
  State<StoresScreen> createState() => _StoresScreenState();
}

class _StoresScreenState extends State<StoresScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.stores();

  void _reload() => setState(() => _future = _repo.stores());

  Future<void> _toggle(Map<String, dynamic> s, bool v) async {
    try {
      await _repo.setStoreActive(s['id'], v);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context)
              .push<bool>(MaterialPageRoute(builder: (_) => const CreateStoreScreen()));
          if (created == true) _reload();
        },
        icon: const Icon(Icons.add),
        label: const Text('متجر جديد'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                const SizedBox(height: 100),
                const Center(child: Text('تعذر تحميل المتاجر')),
                Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
              ]);
            }
            final list = snap.data!;
            if (list.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 100),
                Center(child: Text('لا توجد متاجر بعد. أضف أول متجر بالزر أدناه')),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final s = list[i];
                final cat = (s['store_categories'] is Map) ? s['store_categories']['name'] : null;
                return Card(
                  child: SwitchListTile(
                    value: s['is_active'] == true,
                    onChanged: (v) => _toggle(s, v),
                    title: Text('${s['name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text([
                      if (cat != null) '$cat',
                      if ((s['phone'] ?? '').toString().isNotEmpty) '${s['phone']}',
                      if ((s['address'] ?? '').toString().isNotEmpty) '${s['address']}',
                    ].join(' · ')),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/admin_repository.dart';
import 'account_detail_screen.dart';

const _filters = <(String, String?)>[
  ('الكل', null),
  ('سائقون', 'driver'),
  ('زبائن', 'customer'),
  ('متاجر', 'seller'),
  ('إدارة', 'admin'),
];

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});

  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.accounts();
  String? _role;
  String _query = '';

  void _reload() => setState(() => _future = _repo.accounts());

  bool _matches(Map<String, dynamic> a) {
    if (_role != null && !(a['roles'] as List).contains(_role)) return false;
    if (_query.isEmpty) return true;
    final hay = [a['display_name'], a['full_name'], a['email'], a['phone']]
        .whereType<String>()
        .join(' ')
        .toLowerCase();
    return hay.contains(_query.toLowerCase());
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: TextField(
            onChanged: (v) => setState(() => _query = v.trim()),
            decoration: const InputDecoration(
                hintText: 'بحث بالاسم أو البريد أو الهاتف', prefixIcon: Icon(Icons.search)),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              for (final f in _filters)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                  child: ChoiceChip(
                    label: Text(f.$1),
                    selected: _role == f.$2,
                    onSelected: (_) => setState(() => _role = f.$2),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () async => _reload(),
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return ListView(children: [
                    const SizedBox(height: 100),
                    const Center(child: Text('تعذر تحميل الحسابات')),
                    Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
                  ]);
                }
                final list = snap.data!.where(_matches).toList();
                if (list.isEmpty) {
                  return ListView(children: const [
                    SizedBox(height: 100),
                    Center(child: Text('لا توجد حسابات')),
                  ]);
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final a = list[i];
                    final roles = (a['roles'] as List).cast<String>();
                    final unpaid = (a['unpaid_fees'] as num?)?.toInt() ?? 0;
                    return Card(
                      child: ListTile(
                        title: Text(accountName(a),
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text(
                          '${roles.map((r) => roleAr[r] ?? r).join(' · ')}\n'
                          'كزبون ${a['customer_orders']} · كسائق ${a['driver_orders']}',
                        ),
                        isThreeLine: true,
                        trailing: unpaid > 0
                            ? Chip(
                                label: Text('$unpaid رسوم'),
                                backgroundColor: Colors.red.withValues(alpha: 0.12),
                                labelStyle: const TextStyle(color: Colors.red),
                                side: BorderSide.none)
                            : const Icon(Icons.chevron_left, color: Brand.primary),
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => AccountDetailScreen(account: a)));
                          _reload();
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

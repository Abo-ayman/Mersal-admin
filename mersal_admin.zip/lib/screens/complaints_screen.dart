import 'dart:async';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/admin_repository.dart';
import 'order_chat_screen.dart';

class ComplaintsScreen extends StatefulWidget {
  final VoidCallback? onChanged;
  const ComplaintsScreen({super.key, this.onChanged});

  @override
  State<ComplaintsScreen> createState() => _ComplaintsScreenState();
}

class _ComplaintsScreenState extends State<ComplaintsScreen> {
  final _repo = AdminRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.complaints();

  void _reload() {
    setState(() => _future = _repo.complaints());
    widget.onChanged?.call();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _resolve(Map<String, dynamic> c) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إغلاق الشكوى'),
        content: TextField(
          controller: note,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'ملاحظة عن الحل (اختياري)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('تم الحل')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _repo.resolveComplaint(c['id'],
          note: note.text.trim().isEmpty ? null : note.text.trim());
    } catch (e) {
      _msg(friendlyError(e));
    }
    _reload();
  }

  Widget _card(Map<String, dynamic> c) {
    final open = c['status'] == 'open';
    final phone = '${c['phone']}';
    return Card(
      color: open ? Colors.red.withValues(alpha: 0.05) : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text('شكوى على الطلب #${c['order_number']}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            Chip(
              label: Text(open ? 'مفتوحة' : 'تم الحل'),
              backgroundColor: (open ? Colors.red : Colors.green).withValues(alpha: 0.12),
              side: BorderSide.none,
            ),
          ]),
          Text('الزبون: ${c['customer_name'] ?? '-'}  ·  السائق: ${c['driver_name'] ?? '-'}'),
          Text('التاريخ: ${fmtDate(c['created_at'])}'),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(10)),
            child: Text('${c['body']}'),
          ),
          if ((c['admin_note'] ?? '').toString().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('ملاحظة الإدارة: ${c['admin_note']}',
                  style: const TextStyle(color: Colors.black54)),
            ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Text('ID الطلب: ${c['order_id']}',
                  style: const TextStyle(fontSize: 11, color: Colors.black54),
                  textDirection: TextDirection.ltr),
            ),
            IconButton(
              tooltip: 'نسخ ID الطلب',
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: '${c['order_id']}'));
                _msg('تم نسخ ID الطلب');
              },
              icon: const I3(Icons.copy, size: 18),
            ),
          ]),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => launchUrl(Uri.parse('tel:$phone'),
                    mode: LaunchMode.externalApplication),
                icon: const I3(Icons.call),
                label: Text(phone, textDirection: TextDirection.ltr),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => OrderChatScreen(order: {
                          'id': c['order_id'],
                          'order_number': c['order_number'],
                          'item_name': c['item_name'],
                          'status': c['order_status'],
                          'customer_name': c['customer_name'],
                          'driver_name': c['driver_name'],
                          'total': c['total'],
                          'delivery_total': c['delivery_total'],
                        }))),
                icon: const I3(Icons.chat_bubble_outline),
                label: Text('المحادثة (${c['message_count']})'),
              ),
            ),
          ]),
          if (open) ...[
            const SizedBox(height: 8),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(44)),
              onPressed: () => _resolve(c),
              child: const Text('تم الحل'),
            ),
          ],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => _reload(),
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ListView(children: [
              const SizedBox(height: 100),
              const Center(child: Text('تعذر تحميل الشكاوى')),
              Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
            ]);
          }
          final list = snap.data!;
          if (list.isEmpty) {
            return ListView(children: const [
              SizedBox(height: 100),
              Center(child: Text('لا توجد شكاوى')),
            ]);
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _card(list[i]),
          );
        },
      ),
    );
  }
}

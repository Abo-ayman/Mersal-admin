/// Public values only. Never put a service_role key here.
class AppConfig {
  static const supabaseUrl = 'https://cdovwraosimjhktnkenc.supabase.co';
  static const supabaseKey = 'sb_publishable_BToPU4Q76axfAjnrBQnnlw_zuN6VqcB';
}
